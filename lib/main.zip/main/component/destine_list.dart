import 'package:flutter/material.dart';
import 'package:flutter_state_management/main/route/destine.dart';

class DestineList extends StatelessWidget {
  final String title;
  final List<Destine> destines;
  final void Function(Destine destine)? onTap;
  const DestineList({
    super.key,
    required this.title,
    required this.destines,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 200),
        child: ListView.builder(
          itemCount: destines.length,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return StateManagementCard(destine: destines[index], onTap: onTap);
          },
        ),
      ),
    );
  }
}

class StateManagementCard extends StatelessWidget {
  final Destine destine;
  final void Function(Destine destine)? onTap;
  const StateManagementCard({super.key, required this.destine, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap?.call(destine),
      child: Card(
        elevation: 4,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 150, maxHeight: 150),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(destine.icon, size: 48, color: Colors.blue),
                Text(
                  destine.title,
                  textAlign: TextAlign.center,
                  style: Theme.of(
                    context,
                  ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  destine.description,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
