import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_state_management/main/route/destine.dart';
import 'package:flutter_state_management/main/component/category_title.dart';
import 'package:flutter_state_management/main/component/destine_list.dart';

class StateManagementView extends StatelessWidget {
  final String title;
  final List<Destine> destines;
  final void Function(Destine destine)? onTap;
  const StateManagementView({
    super.key,
    required this.title,
    required this.destines,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final Map<StateManagementType, List<Destine>> groups = destines
        .groupListsBy((Destine destine) => destine.type!);

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(child: CategoryTitle(title: title)),

        ...groups.entries.map((entry) {
          return SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16.0,
                    vertical: 8,
                  ),
                  child: Text(
                    entry.key.name,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.deepPurpleAccent,
                    ),
                  ),
                ),

                SizedBox(
                  height: 8,
                  child: Divider(
                    color: Colors.deepPurple,
                    thickness: 2,
                    indent: 16,
                    endIndent: 16,
                  ),
                ),

                DestineList(
                  title: entry.key.name,
                  destines: entry.value,
                  onTap: onTap,
                ),
              ],
            ),
          );
        }),
      ],
    );
  }
}
