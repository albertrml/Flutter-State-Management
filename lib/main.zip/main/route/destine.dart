import 'package:flutter/material.dart';

enum StateManagementType {
  localState(name: 'Local State'),
  valueNotifier(name: 'ValueNotifier'),
  liftingStateUp(name: 'Lifting State Up'),
  multiprovider(name: 'MultiProvider'),
  blocCubitManual(name: 'BLoC/Cubit Manual'),
  blocProviderLifecycle(name: 'BLoC/Provider Lifecycle');

  final String name;
  const StateManagementType({required this.name});
}

enum StateManagementCategory { ephemeral, app }

sealed class Destine {
  final String title;
  final StateManagementType? type;
  final StateManagementCategory? category;
  final IconData icon;
  final String description;
  final String route;

  Destine({
    required this.title,
    required this.type,
    required this.category,
    required this.icon,
    required this.description,
    required this.route,
  });
}

final class HomePage extends Destine {
  HomePage()
    : super(
        title: 'Home Page',
        type: null,
        category: null,
        icon: Icons.home,
        description: 'Examples of state management',
        route: '/',
      );
}

List<Destine> ephemeralStatedestines = <Destine>[CounterPage(), DayShiftPage()];

List<Destine> appStateDestines = <Destine>[
  TimeSpentPage(),
  CreateColorPage(),
  MoviePage(),
  BlocProviderLifeccyclePage(),
];

// EPHEMERAL STATE MANAGEMENT

// UI/Local State Management
final class CounterPage extends Destine {
  CounterPage()
    : super(
        title: 'Counter',
        type: StateManagementType.localState,
        category: StateManagementCategory.ephemeral,
        icon: Icons.numbers,
        description: 'Example of ephemeral state management by UI state',
        route: '/counter',
      );
}

List<Destine> localStateDestines = <Destine>[CounterPage()];

// Ephemeral State Management by ValueNotifier

final class DayShiftPage extends Destine {
  DayShiftPage()
    : super(
        title: 'Sky Mode',
        type: StateManagementType.valueNotifier,
        category: StateManagementCategory.ephemeral,
        icon: Icons.cloud,
        description: 'Example of ephemeral state management by ValueNotifier',
        route: '/day-shift',
      );
}

// APP STATE MANAGEMENT

// State Management by Lifting State Up
final class TimeSpentPage extends Destine {
  TimeSpentPage()
    : super(
        title: 'Time Spent',
        type: StateManagementType.liftingStateUp,
        category: StateManagementCategory.app,
        icon: Icons.pie_chart,
        description: 'Example of app state management by lifting state up',
        route: '/time-spent',
      );
}

// State Management by Provider
final class CreateColorPage extends Destine {
  CreateColorPage()
    : super(
        title: 'Create RGB Color',
        type: StateManagementType.multiprovider,
        category: StateManagementCategory.app,
        icon: Icons.colorize,
        description:
            'Example of app state management by multiprovider and multiconsumer',
        route: '/create-rgb-color',
      );
}

// State Management by Bloc-Cubit aplying manual instance management.
final class MoviePage extends Destine {
  MoviePage()
    : super(
        title: 'Movie List',
        type: StateManagementType.blocCubitManual,
        category: StateManagementCategory.app,
        icon: Icons.smart_screen,
        description: 'Example of app state management by BLoC and Cubit',
        route: '/movie-screen',
      );
}

// State Management by Bloc-Cubit applying BlocProvider and Cubit lifecycle
final class BlocProviderLifeccyclePage extends Destine {
  BlocProviderLifeccyclePage()
    : super(
        title: 'Bloc Provider Lifecycle',
        type: StateManagementType.blocProviderLifecycle,
        category: StateManagementCategory.app,
        icon: Icons.account_tree,
        description: 'Demonstrates BlocProvider ownership and Cubit lifecycle',
        route: '/bloc-provider-lifecycle',
      );
}
